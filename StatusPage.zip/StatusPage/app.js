const express = require('express');
const path = require('path');
const session = require('express-session');
const fs = require('fs'); // <-- FIX: Added missing File System module
const crypto = require('crypto');

const app = express();
const PORT = 3000;

// --- CONFIGURATION ---

// Admin Credentials (For a real app, use environment variables)
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'password123';

// JAZZCASH SANDBOX DETAILS
const JAZZCASH_CONFIG = {
    MERCHANT_ID: "MC59547",
    PASSWORD:  "e7s6p7g6u2",
    INTEGERITY_SALT: "vg4s47y0y3",
    POST_URL: "https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform"
};

// EASYPAISA SANDBOX DETAILS (REPLACE WITH YOURS)
const EASYPAISA_CONFIG = {
    STORE_ID: "YOUR_STORE_ID",
    HASH_KEY: "YOUR_HASH_KEY",
    POST_URL: "https://sandbox.easypaisa.com.pk/easypay/Index.aspx",
};

// --- DATA HELPER FUNCTIONS (for cars.json) ---
const carsFilePath = path.join(__dirname, 'data', 'cars.json');

const getCars = () => {
    try {
        const carsData = fs.readFileSync(carsFilePath);
        return JSON.parse(carsData);
    } catch (error) {
        console.error("Error reading cars data from cars.json:", error);
        return [];
    }
};

const saveCars = (cars) => {
    try {
        fs.writeFileSync(carsFilePath, JSON.stringify(cars, null, 2));
    } catch (error) {
        console.error("Error saving cars data to cars.json:", error);
    }
};

// --- MIDDLEWARE SETUP ---
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'a-very-secret-key-for-car-rental-site-with-admin',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }
}));

// Custom middleware to make session data available to all templates
app.use((req, res, next) => {
    res.locals.cart = req.session.cart || [];
    res.locals.isAdmin = req.session.isAdmin || false;
    next();
});

// Security Middleware to Protect Admin Routes
const isAdmin = (req, res, next) => {
    if (req.session.isAdmin) {
        return next();
    }
    res.redirect('/admin/login');
};

// --- USER-FACING ROUTES ---

app.get('/', (req, res) => {
    const cars = getCars(); // <-- FIX: Use getCars()
    const featuredCars = cars.filter(car => car.featured);
    res.render('index', { title: 'DriveNow - Premium Car Rentals', cars: featuredCars });
});

app.get('/fleet', (req, res) => {
    let cars = getCars(); // <-- FIX: Use getCars()
    const { type } = req.query;
    if (type && type !== 'all') {
        cars = cars.filter(car => car.type === type);
    }
    const carTypes = [...new Set(getCars().map(car => car.type))];
    res.render('fleet', { title: 'Our Fleet', cars, carTypes, selectedType: type || 'all' });
});

app.get('/car/:id', (req, res) => {
    const cars = getCars(); // <-- FIX: Use getCars()
    const car = cars.find(c => c.id === parseInt(req.params.id));
    if (car) {
        res.render('details', { title: `${car.name} - Details`, car });
    } else {
        res.status(404).send('Car not found');
    }
});

app.get('/about', (req, res) => res.render('about', { title: 'About Us' }));
app.get('/faq', (req, res) => res.render('faq', { title: 'FAQ' }));
app.get('/contact', (req, res) => res.render('contact', { title: 'Contact Us' }));


// --- CART & PAYMENT ROUTES ---

app.post('/cart/add', (req, res) => {
    const cars = getCars(); // <-- FIX: Use getCars()
    const car = cars.find(c => c.id === parseInt(req.body.carId));
    if (car) {
        if (!req.session.cart) req.session.cart = [];
        const pickupDate = new Date(req.body.pickupDate);
        const dropoffDate = new Date(req.body.dropoffDate);
        const days = Math.ceil((dropoffDate - pickupDate) / (1000 * 60 * 60 * 24));
        if (days > 0) {
            req.session.cart.push({ ...car, pickupDate: req.body.pickupDate, dropoffDate: req.body.dropoffDate, days });
        }
    }
    res.redirect('/cart');
});

app.get('/cart', (req, res) => {
    const cart = req.session.cart || [];
    const totalPrice = cart.reduce((total, item) => total + (item.pricePerDay * item.days), 0);
    res.render('cart', { title: 'Your Cart', cart, totalPrice });
});

app.post('/cart/remove/:index', (req, res) => {
    const index = parseInt(req.params.index);
    if (req.session.cart && req.session.cart[index]) {
        req.session.cart.splice(index, 1);
    }
    res.redirect('/cart');
});

app.get('/checkout', (req, res) => {
    const cart = req.session.cart || [];
    if (cart.length === 0) return res.redirect('/cart');
    const totalPrice = cart.reduce((total, item) => total + (item.pricePerDay * item.days), 0);
    res.render('checkout', { title: 'Checkout', totalPrice });
});

app.post('/pay/jazzcash', (req, res) => {
    const cart = req.session.cart || [];
    const amount = cart.reduce((total, item) => total + (item.pricePerDay * item.days), 0);
    const orderRef = "T" + new Date().getTime();

    const data = {
        pp_Version: '2.0',
        pp_TxnType: 'MPAY',
        pp_Language: 'EN',
        pp_MerchantID: JAZZCASH_CONFIG.MERCHANT_ID,
        pp_SubMerchantID: '',
        pp_Password: JAZZCASH_CONFIG.PASSWORD,
        pp_BankID: 'TBANK',
        pp_ProductID: 'RETAIL',
        pp_TxnRefNo: orderRef,
        pp_Amount: amount * 100,
        pp_TxnCurrency: 'PKR',
        pp_TxnDateTime: new Date().toISOString().slice(0, 19).replace(/-/g, "").replace(/:/g, "").replace("T", ""),
        pp_BillReference: orderRef,
        pp_Description: 'Car Rental Payment',
        pp_TxnExpiryDateTime: new Date(new Date().getTime() + (1 * 60 * 60 * 1000)).toISOString().slice(0, 19).replace(/-/g, "").replace(/:/g, "").replace("T", ""),
        pp_ReturnURL: `http://localhost:${PORT}/payment-status`,
        pp_SecureHash: '',
        ppmpf_1: '1', ppmpf_2: '2', ppmpf_3: '3', ppmpf_4: '4', ppmpf_5: '5',
    };

    // FIX: Correct hashing logic for JazzCash
    const sortedData = Object.keys(data).sort().reduce((acc, key) => {
        if (data[key] && key !== 'pp_SecureHash') { // Don't include empty values or the hash itself
            acc[key] = data[key];
        }
        return acc;
    }, {});

    const hashString = JAZZCASH_CONFIG.INTEGERITY_SALT + '&' + Object.values(sortedData).join('&');
    data.pp_SecureHash = crypto.createHmac('sha256', JAZZCASH_CONFIG.INTEGERITY_SALT).update(hashString).digest('hex');

    res.render('payment-redirect', { postURL: JAZZCASH_CONFIG.POST_URL, formData: data });
});

app.post('/pay/easypaisa', (req, res) => { /* ... Easypaisa logic ... */ });

app.all('/payment-status', (req, res) => {
    const responseCode = req.body.pp_ResponseCode; // JazzCash returns this
    if (responseCode === '000') {
        req.session.cart = [];
        res.render('success', { title: 'Payment Successful!' });
    } else {
        res.render('cancel', { title: 'Payment Failed', message: `Transaction failed with code: ${responseCode}` });
    }
});


// --- ADMIN ROUTES ---

app.get('/admin/login', (req, res) => res.render('admin/login', { title: 'Admin Login' }));

app.post('/admin/login', (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USER && password === ADMIN_PASS) {
        req.session.isAdmin = true;
        res.redirect('/admin/dashboard');
    } else {
        res.redirect('/admin/login?error=1');
    }
});

app.get('/admin/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/admin/login'));
});

app.get('/admin/dashboard', isAdmin, (req, res) => {
    const cars = getCars();
    res.render('admin/dashboard', { title: 'Admin Dashboard', cars });
});

app.get('/admin/add', isAdmin, (req, res) => res.render('admin/add-car', { title: 'Add New Car' }));

app.post('/admin/add', isAdmin, (req, res) => {
    const cars = getCars();
    const newCar = {
        id: Date.now(),
        name: req.body.name,
        type: req.body.type,
        pricePerDay: parseInt(req.body.pricePerDay),
        seats: parseInt(req.body.seats),
        fuel: req.body.fuel,
        image: `/images/${req.body.image}`,
        description: req.body.description,
        featured: req.body.featured === 'on'
    };
    cars.push(newCar);
    saveCars(cars);
    res.redirect('/admin/dashboard');
});

app.get('/admin/edit/:id', isAdmin, (req, res) => {
    const cars = getCars();
    const car = cars.find(c => c.id === parseInt(req.params.id));
    if (car) {
        res.render('admin/edit-car', { title: 'Edit Car', car });
    } else {
        res.redirect('/admin/dashboard');
    }
});

app.post('/admin/edit/:id', isAdmin, (req, res) => {
    let cars = getCars();
    const carIndex = cars.findIndex(c => c.id === parseInt(req.params.id));
    if (carIndex !== -1) {
        cars[carIndex] = {
            id: parseInt(req.params.id),
            name: req.body.name, type: req.body.type,
            pricePerDay: parseInt(req.body.pricePerDay),
            seats: parseInt(req.body.seats), fuel: req.body.fuel,
            image: `/images/${req.body.image}`,
            description: req.body.description,
            featured: req.body.featured === 'on'
        };
        saveCars(cars);
    }
    res.redirect('/admin/dashboard');
});

app.post('/admin/delete/:id', isAdmin, (req, res) => {
    let cars = getCars();
    cars = cars.filter(c => c.id !== parseInt(req.params.id));
    saveCars(cars);
    res.redirect('/admin/dashboard');
});

// --- START SERVER ---
app.listen(PORT, () => {
    console.log(`Server with Admin Panel is running at http://localhost:${PORT}`);
    console.log(`Admin login: http://localhost:${PORT}/admin/login (user: admin, pass: password123)`);
});