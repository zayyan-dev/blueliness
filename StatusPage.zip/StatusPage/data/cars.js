const cars = [
    {
        id: 1,
        name: 'Tesla Model S',
        type: 'Electric',
        image: '/images/tesla-model-s.png',
        pricePerDay: 150,
        seats: 5,
        fuel: 'Electric',
        description: 'Experience the future of driving with the Tesla Model S. Blistering acceleration, long range, and a minimalist interior.',
        featured: true
    },
    {
        id: 2,
        name: 'BMW M3',
        type: 'Sports',
        image: '/images/bmw-m3.png',
        pricePerDay: 200,
        seats: 4,
        fuel: 'Gasoline',
        description: 'The BMW M3 is the ultimate driving machine. With its powerful engine and precision handling, it delivers an exhilarating ride.',
        featured: false
    },
    {
        id: 3,
        name: 'Toyota Camry',
        type: 'Sedan',
        image: '/images/toyota-camry.png',
        pricePerDay: 75,
        seats: 5,
        fuel: 'Gasoline',
        description: 'Reliable, comfortable, and fuel-efficient. The Toyota Camry is the perfect choice for family trips or business travel.',
        featured: false
    },
    {
        id: 4,
        name: 'Ford Explorer',
        type: 'SUV',
        image: '/images/ford-explorer.png',
        pricePerDay: 110,
        seats: 7,
        fuel: 'Gasoline',
        description: 'Spacious and versatile, the Ford Explorer is built for adventure. Plenty of room for passengers and cargo.',
        featured: true
    },
    {
        id: 5,
        name: 'Jeep Wrangler',
        type: 'Off-road',
        image: '/images/jeep-wrangler.png',
        pricePerDay: 130,
        seats: 4,
        fuel: 'Gasoline',
        description: 'Conquer any terrain with the legendary Jeep Wrangler. The ultimate choice for off-road enthusiasts.',
        featured: false
    },
    {
        id: 6,
        name: 'Porsche 911',
        type: 'Sports',
        image: '/images/porsche-911.png',
        pricePerDay: 350,
        seats: 2,
        fuel: 'Gasoline',
        description: 'An iconic sports car with timeless design and breathtaking performance. The Porsche 911 is an unforgettable experience.',
        featured: true
    }
];

module.exports = cars;